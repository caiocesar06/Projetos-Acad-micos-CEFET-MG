public class DaoPatternDemo {
    
    public static void main(String[] args) {
        new PessoalDaoImpl();
    }
}
